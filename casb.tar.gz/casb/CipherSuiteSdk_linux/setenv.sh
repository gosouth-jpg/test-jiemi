#!/bin/bash

export LD_LIBRARY_PATH=/opt/casb/CipherSuiteSdk_linux/lib
