#!/bin/bash

flag=0
for i in $*;do 
	if [ $flag -eq 1 ];then
		export CS_CONFIG_PATH=$i
		flag=0
	elif [ $flag -eq 2 ];then
		export CS_LOG_FLAG=$i
		flag=0
	elif [ $flag -eq 3 ];then
		export CS_LOG_PATH=$i
		flag=0
	elif [ $flag -eq 4 ];then
		export PATH=$i/lib:$PATH
		flag=0
		fi

	if [ $i == "-CONFIGPATH" ];then
		flag=1
	elif [ $i == "-LOGFLAG" ];then
		flag=2
	elif [ $i == "-LOGPATH" ];then
		flag=3
	elif [ $i == "-SDK_BASE_PATH" ];then
		flag=4
	fi
done

sdkAuxiliaryTools $1

